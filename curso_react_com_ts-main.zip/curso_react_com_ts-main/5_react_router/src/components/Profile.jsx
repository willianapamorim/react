import React from "react";

const Profile = () => {
  return (
    <div>
      <h3>Perfil do Usuário</h3> {/* Conteúdo do perfil */}
    </div>
  );
};

export default Profile;
