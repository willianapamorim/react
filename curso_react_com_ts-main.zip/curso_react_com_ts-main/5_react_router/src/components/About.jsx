import React from "react";

const About = () => {
  return (
    <div>
      <h1>Sobre</h1>
      <p>Esta é a página sobre nós.</p>
    </div>
  );
};

export default About;
