import React from "react";

const Settings = () => {
  return (
    <div>
      <h3>Configurações</h3> {/* Conteúdo das configurações */}
    </div>
  );
};

export default Settings;
