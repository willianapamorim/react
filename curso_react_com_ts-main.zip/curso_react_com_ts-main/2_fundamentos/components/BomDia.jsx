import React from "react";

const BomDia = () => {
  const name = "Matheus";

  return <div>Bom dia {name}!</div>;
};

export default BomDia;
