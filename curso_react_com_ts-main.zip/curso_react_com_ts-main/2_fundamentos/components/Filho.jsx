import React from "react";

const Filho = () => {
  return <div>Filho</div>;
};

export default Filho;
