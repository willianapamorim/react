import React from "react";
import Filho from "./Filho";

const Pai = () => {
  return (
    <div>
      <Filho />
      <Filho />
    </div>
  );
};

export default Pai;
